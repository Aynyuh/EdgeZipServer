# Free Itinerary HTML Template
Gloo is a very simple, clean, and responsive bootstrap free Itinerary HTML template. Which will help you to create itinerary page for Travel and Flight itinerary.

## Demo:
Click this link for a live demo : <a href="http://demo.harnishdesign.net/html/gloo/demos.html">View a Demo here</a>

## Overview:
Click this link for a live Template Overview : <a href="http://www.harnishdesign.net/free-itinerary-html-template/">Template Overview Page</a>

## Credits:
<ul>
<li><a href="http://getbootstrap.com/">Bootstrap 4</a></li>
<li><a href="https://fontawesome.com/">Font Awesome</a></li>
<li><a href="https://fonts.google.com/">Google Fonts</a></li>
</ul>

## Created By:
<a href="http://www.harnishdesign.net/">Harnish Design</a>

## License:
See the LICENSE file for license rights and limitations (MIT).
